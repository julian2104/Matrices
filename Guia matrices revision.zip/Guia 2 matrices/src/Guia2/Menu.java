package Guia2;

import java.util.Scanner;

public class Menu {

    public static int fil, colum;

    public static void main(String[] args) {
        Scanner ingreso = new Scanner(System.in);
        calculoMatrices matriz = new calculoMatrices();
        char op, op2;
        
        do {
            System.out.println("\n\t Elija la opcion deseada\n1.Calculadora matrices.\n2.Prueba algoritmos.\n3.Datos personas.\n4.Terminar.");
            op2 = ingreso.next().charAt(0);
            ingreso.nextLine();
            
            switch (op2) {
                case '1':
                    System.out.println("\t operaciones entre matrices \n1. Suma de Matrices \n2. Producto de Matrices\n3. Producto de un escalar con una Matriz \n4. Transpuesta de una Matriz \n5. Terminar");
                    op = ingreso.next().charAt(0);
                    ingreso.nextLine();
                    
                    switch (op) {
                        case '1':
                        case '2':
                        case '3':
                        case '4':
                            System.out.println("Digite el numero de Filas y Columnas de las matrices");
                            matriz.fila = ingreso.nextInt();
                            fil = matriz.fila;
                            matriz.columna = ingreso.nextInt();
                            colum = matriz.columna;
                            
                            System.out.println("Digite los numeros de las filas de la matriz 1 en orden");
                            for (int i = 0; i < fil; i++) {
                                for (int j = 0; j < colum; j++) {
                                    System.out.println("Ingrese el numero ");
                                    matriz.a[i][j] = ingreso.nextInt();
                                }
                            }
                            
                            System.out.println("Digite los numeros de las filas de la matriz 2 en orden");
                            for (int i = 0; i < fil; i++) {
                                for (int j = 0; j < colum; j++) {
                                    System.out.println("Ingrese el numero ");
                                    matriz.b[i][j] = ingreso.nextInt();
                                }
                            }
                            
                            if(op == '1')
                                matriz.suma();
                            else if(op == '2')
                                matriz.multi(fil, colum, fil, colum);
                            else if(op == '3') {
                                System.out.println("Digite el numero que va a multiplicar la matriz: ");
                                matriz.n = ingreso.nextInt();
                                matriz.produc(fil, colum);
                            }
                            else
                                matriz.trans();
                            
                            System.out.println("La matriz resultante es:");
                            System.out.print(" ");
                            for (int j = 0; j < colum; j++) {
                                System.out.print("----");
                            }
                            System.out.println("-");
                            for (int i = 0; i < fil; i++) {
                                System.out.print("|");
                                for (int j = 0; j < colum; j++) {
                                    System.out.print(String.format("%3d", matriz.a[i][j]));
                                }
                                System.out.println(" |");
                            }
                            System.out.print(" ");
                            for (int j = 0; j < colum; j++) {
                                System.out.print("----");
                            }
                            System.out.println("-");
                            break;
                    }
                    break;
                    
                case '2':
                    TiempoAlgoritmos testAlgs = new TiempoAlgoritmos();
                    testAlgs.prueba(100);
                    testAlgs.prueba(500);
                    testAlgs.prueba(1000);
                    testAlgs.prueba(5000);
                    testAlgs.prueba(10000);
                    break;
                    
                case '3':
                    Interfaz personas = new Interfaz();
                    personas.setVisible(true);
                    break;
            }
        } while (op2 != '4');
        System.out.println("Fin del programa");
    }
}
