package Guia2;
public class calculoMatrices {
    public int fila, columna, n;
    int[][] a = new int[100][100];
    int[][] b = new int[100][100];

    public void suma() {
        for (int x = 0; x < fila; x++) {
            for (int y = 0; y < columna; y++) {
                a[x][y] += b[x][y];
            }
        }
    }

    public void resta() {
        for (int x = 0; x < fila; x++) {
            for (int y = 0; y < columna; y++) {
                a[x][y] -= b[x][y];
            }
        }
    }

    public void multi(int filaA, int columnaA, int filaB, int columnaB) {
        if (columnaA == filaB) {
            int[][] temp = new int[filaA][columnaB];
            for (int x = 0; x < filaA; x++) {
                for (int y = 0; y < columnaB; y++) {
                    int suma = 0;
                    for (int z = 0; z < columnaA; z++) {
                        suma += a[x][z] * b[z][y];
                    }
                    temp[x][y] = suma;
                }
            }
            a = temp; 
        } else {
            System.out.println("Las matrices no son compatibles");
        }
    }

    public void produc(int filaA, int columnaA) {
        for (int x = 0; x < filaA; x++) {
            for (int y = 0; y < columnaA; y++) {
                a[x][y] *= n;
            }
        }
    }

    public void trans() {
        int[][] temp = new int[columna][fila]; 
        for (int x = 0; x < fila; x++) {
            for (int y = 0; y < columna; y++) {
                temp[y][x] = a[x][y];
            }
        }
        a = temp; 
    }
}

    