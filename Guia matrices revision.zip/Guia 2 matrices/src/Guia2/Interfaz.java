package Guia2;
import java.util.HashMap;
import java.awt.*;
import javax.swing.*;
import javax.swing.border.Border;

public class Interfaz extends javax.swing.JFrame {
    int n=100, i=0, tamaño;
    int[] cedula = new int[n];
    double[] edad = new double[n];
    double[] estatura = new double[n];
    String[] nombre = new String[n];    
    Metodos algoritmos = new Metodos();
    public Interfaz() {
        initComponents();
        Color diferente = new Color(255,255,255);
        getContentPane().setBackground(diferente);
        Border textAreaBorder = BorderFactory.createLineBorder(Color.orange, 3);
        listaOriginal.setBorder(textAreaBorder);
        listaOrdenada.setBorder(textAreaBorder);
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Nombre = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        Cedula = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        Edad = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        Estatura = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        newPersona = new javax.swing.JButton();
        Tipodato = new javax.swing.JComboBox<>();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        Tipoordenamiento = new javax.swing.JComboBox<>();
        Ordenar = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        listaOriginal = new javax.swing.JTextArea();
        jScrollPane2 = new javax.swing.JScrollPane();
        listaOrdenada = new javax.swing.JTextArea();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 255));

        Nombre.setFont(new java.awt.Font("Hack Nerd Font", 0, 14)); // NOI18N
        Nombre.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        Nombre.setCaretColor(new java.awt.Color(72, 112, 255));
        Nombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NombreActionPerformed(evt);
            }
        });

        jLabel1.setBackground(new java.awt.Color(204, 0, 0));
        jLabel1.setFont(new java.awt.Font("Hack Nerd Font", 1, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 51, 51));
        jLabel1.setText("Nombres y apellidos");

        Cedula.setFont(new java.awt.Font("Hack Nerd Font", 0, 14)); // NOI18N
        Cedula.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        Cedula.setCaretColor(new java.awt.Color(72, 112, 255));
        Cedula.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CedulaActionPerformed(evt);
            }
        });

        jLabel2.setBackground(new java.awt.Color(255, 0, 0));
        jLabel2.setFont(new java.awt.Font("Hack Nerd Font", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(204, 0, 0));
        jLabel2.setText("Documento de indentificacion");

        Edad.setFont(new java.awt.Font("Hack Nerd Font", 0, 14)); // NOI18N
        Edad.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        Edad.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        Edad.setCaretColor(new java.awt.Color(72, 112, 255));
        Edad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EdadActionPerformed(evt);
            }
        });

        jLabel3.setBackground(new java.awt.Color(102, 0, 153));
        jLabel3.setFont(new java.awt.Font("Hack Nerd Font", 1, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 51, 51));
        jLabel3.setText("Edad:");

        Estatura.setFont(new java.awt.Font("Hack Nerd Font", 0, 14)); // NOI18N
        Estatura.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        Estatura.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        Estatura.setCaretColor(new java.awt.Color(72, 112, 255));
        Estatura.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EstaturaActionPerformed(evt);
            }
        });

        jLabel4.setBackground(new java.awt.Color(102, 0, 153));
        jLabel4.setFont(new java.awt.Font("Hack Nerd Font", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 0, 0));
        jLabel4.setText("Estatura:");

        newPersona.setFont(new java.awt.Font("Hack Nerd Font", 1, 14)); // NOI18N
        newPersona.setText("Ingresar");
        newPersona.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        newPersona.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                newPersonaActionPerformed(evt);
            }
        });

        Tipodato.setFont(new java.awt.Font("Hack Nerd Font", 3, 12)); // NOI18N
        Tipodato.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "- Opcion -", "Altura", "Edad" }));
        Tipodato.setBorder(null);
        Tipodato.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Tipodato.setOpaque(true);
        Tipodato.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TipodatoActionPerformed(evt);
            }
        });

        jLabel5.setBackground(new java.awt.Color(173, 139, 235));
        jLabel5.setFont(new java.awt.Font("Hack Nerd Font", 1, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 51, 51));
        jLabel5.setText("Seleccione el dato a ordenar");

        jLabel6.setBackground(new java.awt.Color(173, 139, 235));
        jLabel6.setFont(new java.awt.Font("Hack Nerd Font", 1, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 51, 51));
        jLabel6.setText("Ordenamiento deseado:");

        Tipoordenamiento.setFont(new java.awt.Font("Hack Nerd Font", 3, 12)); // NOI18N
        Tipoordenamiento.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "- Opcion -", "Burbuja", "Mergesort", " " }));
        Tipoordenamiento.setBorder(null);
        Tipoordenamiento.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Tipoordenamiento.setOpaque(true);
        Tipoordenamiento.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TipoordenamientoActionPerformed(evt);
            }
        });

        Ordenar.setFont(new java.awt.Font("Hack Nerd Font", 1, 14)); // NOI18N
        Ordenar.setText("Ordenar");
        Ordenar.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Ordenar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                OrdenarActionPerformed(evt);
            }
        });

        jLabel7.setBackground(new java.awt.Color(173, 139, 235));
        jLabel7.setFont(new java.awt.Font("Hack Nerd Font Mono", 1, 15)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 0, 0));
        jLabel7.setText("Datos de personas Ingresadas");

        jLabel8.setBackground(new java.awt.Color(173, 139, 235));
        jLabel8.setFont(new java.awt.Font("Hack Nerd Font", 1, 15)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 51, 0));
        jLabel8.setText("Lista de personas ordeanadas por metodo");

        listaOriginal.setColumns(20);
        listaOriginal.setFont(new java.awt.Font("Hack Nerd Font", 0, 12)); // NOI18N
        listaOriginal.setRows(5);
        listaOriginal.setBorder(new javax.swing.border.MatteBorder(null));
        listaOriginal.setCaretColor(new java.awt.Color(45, 45, 45));
        listaOriginal.setHighlighter(null);
        listaOriginal.setMargin(new java.awt.Insets(0, 0, 0, 0));
        listaOriginal.setSelectedTextColor(new java.awt.Color(0, 0, 0));
        listaOriginal.setSelectionColor(new java.awt.Color(255, 0, 255));
        jScrollPane1.setViewportView(listaOriginal);

        listaOrdenada.setColumns(20);
        listaOrdenada.setFont(new java.awt.Font("Hack Nerd Font", 0, 12)); // NOI18N
        listaOrdenada.setRows(5);
        listaOrdenada.setBorder(new javax.swing.border.MatteBorder(null));
        listaOrdenada.setCaretColor(new java.awt.Color(45, 45, 45));
        listaOrdenada.setSelectedTextColor(new java.awt.Color(0, 0, 0));
        listaOrdenada.setSelectionColor(new java.awt.Color(255, 0, 255));
        jScrollPane2.setViewportView(listaOrdenada);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(Edad, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(12, 12, 12)
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(Estatura, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jLabel1)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel2)
                            .addComponent(Nombre)
                            .addComponent(Cedula, javax.swing.GroupLayout.PREFERRED_SIZE, 299, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(71, 71, 71)
                                .addComponent(newPersona, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addGap(39, 39, 39)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 272, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(37, 37, 37)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(Tipodato, javax.swing.GroupLayout.PREFERRED_SIZE, 186, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6)
                            .addComponent(jLabel5)
                            .addComponent(Tipoordenamiento, javax.swing.GroupLayout.PREFERRED_SIZE, 186, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(32, 32, 32)
                                .addComponent(Ordenar, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addComponent(jLabel7))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 280, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8))
                .addContainerGap(102, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jLabel7))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(41, 41, 41)
                                .addComponent(jLabel1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(Nombre, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel4)
                                    .addComponent(Estatura, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel3)
                                    .addComponent(Edad, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(Cedula, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(newPersona))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(35, 35, 35)
                                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(Tipodato, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(27, 27, 27)
                                .addComponent(jLabel6)
                                .addGap(18, 18, 18)
                                .addComponent(Tipoordenamiento, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(26, 26, 26)
                                .addComponent(Ordenar)))
                        .addGap(0, 127, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 315, Short.MAX_VALUE)
                            .addComponent(jScrollPane2))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void NombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NombreActionPerformed
        
    }//GEN-LAST:event_NombreActionPerformed

    private void CedulaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CedulaActionPerformed
        
    }//GEN-LAST:event_CedulaActionPerformed

    private void EdadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EdadActionPerformed
        
    }//GEN-LAST:event_EdadActionPerformed

    private void EstaturaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EstaturaActionPerformed
        
    }//GEN-LAST:event_EstaturaActionPerformed

    private void OrdenarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_OrdenarActionPerformed

        
if (Tipodato.getSelectedItem().equals("Edad")) {
    double[] copiaEdad = new double[edad.length];
    for (int k = 0; k < edad.length; k++) {
        copiaEdad[k] = edad[k];
    }
    if (Tipoordenamiento.getSelectedItem().equals("Burbuja")) {
        algoritmos.MetodBurbuja(copiaEdad.length, copiaEdad);
    } else {
        algoritmos.MetodmergeSort(copiaEdad, 0, copiaEdad.length - 1);
    }
    for (int j = 0; j < i; j++) {
        escribirListaOrdenadaEdades(copiaEdad);
    }
} else {
    double[] copiaEstatura = new double[estatura.length];
    for (int k = 0; k < estatura.length; k++) {
        copiaEstatura[k] = estatura[k];
    }
    if (Tipoordenamiento.getSelectedItem().equals("Burbuja")) {
        algoritmos.MetodBurbuja(copiaEstatura.length, copiaEstatura);
    } else {
        algoritmos.MetodmergeSort(copiaEstatura, 0, copiaEstatura.length - 1);
    }
    escribirListaOrdenadaEstatura(copiaEstatura);
}
    }//GEN-LAST:event_OrdenarActionPerformed
    public double[] copy(double[] data){
        for (int j = 0; j < data.length; j++) {
            if(data[j]!=0){
                tamaño++;
            }
        }
        double[] copia = new double[tamaño];
        System.arraycopy(data, 0, copia, 0, tamaño);
        return copia;
    }
    private void newPersonaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_newPersonaActionPerformed
    nombre[i] = Nombre.getText();
    Nombre.setText(""); 
    String texto1 = Cedula.getText();
    cedula[i] = Integer.parseInt(texto1);
    Cedula.setText("");
    String texto2 = Edad.getText();
    edad[i] = Double.parseDouble(texto2);
    Edad.setText(""); 
    String texto3 = Estatura.getText();
    estatura[i] = Double.parseDouble(texto3);
    Estatura.setText(""); 
    i++;
    escribirListaOriginal();
    }//GEN-LAST:event_newPersonaActionPerformed
    private void escribirListaOriginal() {
        StringBuilder texto = new StringBuilder();
        for (int j = 0; j < i; j++) {
            texto.append("Nombre: ").append(nombre[j]).append(", Cedula: ").append(cedula[j]).append(", Edad: ").append(edad[j]).append(", Estatura: ").append(estatura[j]).append("\n");
        }
        listaOriginal.setText(texto.toString());
    }
    private void escribirListaOrdenadaEdades(double[] copia){
        StringBuilder texto = new StringBuilder();
        HashMap<Double, Boolean> edadesProcesadas = new HashMap<>();

        for (int j = 0; j < tamaño; j++) {
            if (!edadesProcesadas.containsKey(copia[j])) {
                for (int k = 0; k < i; k++) { 
                    if (edad[k] == copia[j]) {
                        texto.append("Nombre: ").append(nombre[k]).append(", Edad: ").append(edad[k]).append("\n");
                        System.out.println(edad[k]);
                    }
                }
                edadesProcesadas.put(copia[j], true);
            }
        }

        listaOrdenada.setText(texto.toString());
    }
    private void escribirListaOrdenadaEstatura(double[] copia){
        StringBuilder texto = new StringBuilder();
        HashMap<Double, Boolean> estaturasProcesadas = new HashMap<>();

        for (int j = 0; j < tamaño; j++) {
            if (!estaturasProcesadas.containsKey(copia[j])) {
                for (int k = 0; k < i; k++) { 
                    if (estatura[k] == copia[j]) {
                        texto.append("Nombre: ").append(nombre[k]).append(", Estatura: ").append(estatura[k]).append("\n");
                    }
                }
                estaturasProcesadas.put(copia[j], true);
            }
        }

        listaOrdenada.setText(texto.toString());
    }
    private void TipodatoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TipodatoActionPerformed
        
    }//GEN-LAST:event_TipodatoActionPerformed

    private void TipoordenamientoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TipoordenamientoActionPerformed

    }//GEN-LAST:event_TipoordenamientoActionPerformed


    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Interfaz().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField Cedula;
    private javax.swing.JTextField Edad;
    private javax.swing.JTextField Estatura;
    private javax.swing.JTextField Nombre;
    private javax.swing.JButton Ordenar;
    private javax.swing.JComboBox<String> Tipodato;
    private javax.swing.JComboBox<String> Tipoordenamiento;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextArea listaOrdenada;
    private javax.swing.JTextArea listaOriginal;
    private javax.swing.JButton newPersona;
    // End of variables declaration//GEN-END:variables
}
