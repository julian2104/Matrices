package Guia2;

public class TiempoAlgoritmos {
    Metodos algoritmos = new Metodos();
    String[] metodos = new String[]{"MetodoBurbuja", "MetodoSeleccion", "MetodoInsercion", "MetodoMerge"};

    public void prueba(int tamaño) {
        double[] datos = generarDatos(tamaño);
        System.out.println("Datos a analizados: " + tamaño);

        double[] executionTime = new double[4];

        executionTime[0] = medirTiempo(algoritmos::MetodBurbuja, tamaño, datos);
        System.out.println("\tMetodo burbuja: " + executionTime[0]);

        executionTime[1] = medirTiempo(algoritmos::Metodseleccion, tamaño, datos);
        System.out.println("\tMetodo seleccion: " + executionTime[1]);

        executionTime[2] = medirTiempo(algoritmos::Metodinsercion, tamaño, datos);
        System.out.println("\tMetodo insercion: " + executionTime[2]);

        executionTime[3] = medirTiempo((t, d) -> algoritmos.MetodmergeSort(d, 0, t - 1), tamaño, datos);
        System.out.println("\tMetodo merge: " + executionTime[3]);

        double[] copia = new Interfaz().copy(executionTime);
        algoritmos.MetodBurbuja(4, copia);

        for (int i = 0; i < 4; i++) {
            if (copia[0] == executionTime[i])
                System.out.println("EL menor tiempo lo tiene " + copia[0] + ", el metodo: " + metodos[i] + "\n");
        }
    }

    private double[] generarDatos(int tamaño) {
        double[] datos = new double[tamaño];
        for (int i = 0; i < tamaño; i++) {
            datos[i] = (Math.random() * 100);
        }
        return datos;
    }

    private double medirTiempo(Algoritmo algoritmo, int tamaño, double[] datos) {
        double startTime = System.nanoTime();
        algoritmo.ejecutar(tamaño, datos);
        double endTime = System.nanoTime();
        return endTime - startTime;
    }

    interface Algoritmo {
        void ejecutar(int tamaño, double[] datos);
    }
}